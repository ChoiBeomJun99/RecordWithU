package com.example.rwu2

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.viewpager2.widget.ViewPager2
import com.example.rwu2.databinding.FragmentPlusBinding
import com.example.rwu2.recordView.CalendarAdapter
import com.example.rwu2.recordView.PlusViewPagerAdapter
import java.util.*
import kotlin.collections.ArrayList


class PlusFragment : Fragment() {
    private val MIN_SCALE = 0.85f // 뷰가 몇퍼센트로 줄어들 것인지
    private val MIN_ALPHA = 0.5f // 어두워지는 정도를 나타낸 듯 하다.

    var recordArr = arrayListOf<RecordFromDB>()
    var planArr = arrayListOf<PlanFromDB>()
    var binding:FragmentPlusBinding ?= null // 메모리 누수 가능성 때문에 null 값이 가능한 변수로 선언해주는것을 주의하자
    lateinit var pvpAdapter:PlusViewPagerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentPlusBinding.inflate(layoutInflater,container,false)
        return binding!!.root
    }

    // 프레그먼트 객체가 실체화(inflate)된 후에 호출되는 함수
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initArrays()
        initPagerView()
        initCalendar()

    }

    private fun initCalendar() {
        binding!!.apply {
            var calAdapter:CalendarAdapter
//            calAdapter = CalendarAdapter(context,Date)
        }
    }


    private fun initPagerView() {
        binding!!.apply {
            pvpAdapter = PlusViewPagerAdapter(getRecordList(),getPlanList())

            /* 여백, 너비에 대한 정의 */
//            binding!!.recordViewPager.setPageTransformer(ZoomOutPageTransformer())
            val pageMarginPx = resources.getDimensionPixelOffset(R.dimen.pageMargin) // dimen 파일 안에 크기를 정의해두었다.
            val pagerWidth = resources.getDimensionPixelOffset(R.dimen.pageWidth) // dimen 파일이 없으면 생성해야함
            val screenWidth = resources.displayMetrics.widthPixels // 스마트폰의 너비 길이를 가져옴
            val offsetPx = screenWidth - pageMarginPx - pagerWidth
            binding!!.recordViewPager.setPageTransformer{ page, position ->
                page.translationX = position * -offsetPx
            }
            binding!!.recordViewPager.offscreenPageLimit = 1 // 몇개의 페이지를 미리 로드해둘 것인지


            pvpAdapter.setOnItemClickListener(object :PlusViewPagerAdapter.OnItemClickListener{
                override fun OnItemClick(v: View,recordData:RecordFromDB,planData:PlanFromDB) {
                    super.OnItemClick(v, recordData,planData)
                    if(v is ImageView){
                        v.setImageResource(planData.imgURL.toInt())
                    }else if(v is TextView){
                        v.setText(planData.text)
                    }else{}

                }
            })







            recordViewPager.adapter = pvpAdapter
        }
    }

    // 뷰 페이저에 들어갈 아이템
    private fun getRecordList(): ArrayList<RecordFromDB> {
        // 여기의 리스트를 그림 받아와서 진행
        return recordArr
    }

    private fun getPlanList(): ArrayList<PlanFromDB> {
        // 여기의 리스트를 그림 받아와서 진행
        return planArr
    }

    // DB 에서 값 받아와 recordArr,planArr 채워주는 함수
    private fun initArrays(){
        // Dummy 값들임
        recordArr = arrayListOf(RecordFromDB("Dummy Title",R.drawable.profileimage.toString(),1.0,2.0,"Dummy text","Dummy date"),
            RecordFromDB("Dummy Title1",R.drawable.logo_kako_login.toString(),1.0,2.0,"Dummy text","Dummy date"),
            RecordFromDB("Dummy Title2",R.drawable.logo_kako_login.toString(),1.0,2.0,"Dummy text","Dummy date"),
            RecordFromDB("Dummy Title3",R.drawable.logo_kako_login.toString(),1.0,2.0,"Dummy text","Dummy date"))
        planArr = arrayListOf(PlanFromDB("Dummy Title",R.drawable.homeimage.toString(),1.0,2.0,"Dummy text","Dummy date"),
            PlanFromDB("Dummy Title1",R.drawable.homeimage.toString(),1.0,2.0,"Dummy text","Dummy date"),
            PlanFromDB("Dummy Title2",R.drawable.homeimage.toString(),1.0,2.0,"Dummy text","Dummy date"),
            PlanFromDB("Dummy Title3",R.drawable.homeimage.toString(),1.0,2.0,"Dummy text","Dummy date"))
    }

    /* 공식문서에 있는 코드 긁어온거임 */
    inner class ZoomOutPageTransformer : ViewPager2.PageTransformer {
        override fun transformPage(view: View, position: Float) {
            view.apply {
                val pageWidth = width
                val pageHeight = height
                when {
                    position < -1 -> { // [-Infinity,-1)
                        // This page is way off-screen to the left.
                        alpha = 0f
                    }
                    position <= 1 -> { // [-1,1]
                        // Modify the default slide transition to shrink the page as well
                        val scaleFactor = Math.max(MIN_SCALE, 1 - Math.abs(position))
                        val vertMargin = pageHeight * (1 - scaleFactor) / 2
                        val horzMargin = pageWidth * (1 - scaleFactor) / 2
                        translationX = if (position < 0) {
                            horzMargin - vertMargin / 2
                        } else {
                            horzMargin + vertMargin / 2
                        }

                        // Scale the page down (between MIN_SCALE and 1)
                        scaleX = scaleFactor
                        scaleY = scaleFactor

                        // Fade the page relative to its size.
                        alpha = (MIN_ALPHA +
                                (((scaleFactor - MIN_SCALE) / (1 - MIN_SCALE)) * (1 - MIN_ALPHA)))
                    }
                    else -> { // (1,+Infinity]
                        // This page is way off-screen to the right.
                        alpha = 0f
                    }
                }
            }
        }
    }
}